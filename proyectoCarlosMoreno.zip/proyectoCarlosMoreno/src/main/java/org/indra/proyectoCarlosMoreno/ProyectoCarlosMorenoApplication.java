package org.indra.proyectoCarlosMoreno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoCarlosMorenoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoCarlosMorenoApplication.class, args);
	}

}
