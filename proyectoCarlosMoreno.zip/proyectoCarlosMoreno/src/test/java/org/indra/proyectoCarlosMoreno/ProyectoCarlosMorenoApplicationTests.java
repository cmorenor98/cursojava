package org.indra.proyectoCarlosMoreno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCarlosMorenoApplicationTests {

	@Test
	void contextLoads() {
	}

}
