package org.indra.model;

public interface IObserver {
	
	void notificar(Object cambio);
	
}
